hello <-
function(x) {
cat("Hello", x, "!\n")
}
